<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4 py-3 border-left-primary">
                    <div class="card-body">
                        <h5 class="font-weight-bold text-primary">Periode Aktif 
                            <span class="badge badge-pill badge-primary"><?php echo e($periode->year); ?></span>
                        </button></h5>
                        <form action="<?php echo e(route('periode.update')); ?>" method="post" class="form-inline mt-4">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mx-sm-2 mb-2">
                                <label for="inputPassword2" class="sr-only">Password</label>
                                <select name="name" id="name" class="form-control" aria-describedby="button-addon2">
                                    <option value="" selected disabled>Pilih Tahun Periode </option>
                                    <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($year->name); ?>"><?php echo e($year->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary mb-2">Ubah Periode</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\projects\monev-tekkom\resources\views/periode/index.blade.php ENDPATH**/ ?>