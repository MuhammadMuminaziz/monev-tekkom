<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card shadow border-bottom-primary">
                    <div class="card-header">
                        <h6 class="m-0 font-weight-bold text-primary">Laporan Data Sekolah</h6>
                    </div>
                    <div class="card-body">
                        <div class="row p-3">
                            <div class="col-md-6 d-flex">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <label class="btn btn-primary" for="filterDistrict" id="btn-filter">Filter</label>
                                    </div>
                                    <select class="custom-select" id="filterDistrict">
                                        <option selected disabled>- Pilih Kecamatan -</option>
                                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <a href="<?php echo e(route('reporting.index')); ?>" class="ml-3">
                                    <button class="btn btn-danger mb-3" type="button">Reset</button>
                                </a>
                            </div>
                            <div class="col-md-6 d-flex justify-content-end">
                                <a href="" class="d-none" id="schools-data">
                                    <button class="btn btn-primary"><i class="fas fa-print"></i> Print semua data</button>
                                </a>
                            </div>
                        </div>

                        <div class="row p-2">
                            <div class="col">
                                <div class="table-responsive">
                                    <table class="table " id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th scope="col">Nama Sekolah</th>
                                                <th>NPSN</th>
                                                <th>Kecamatan</th>
                                                <th>Kota</th>
                                                <th>Dokumen</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody id="page-school">
                                            <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($school->name); ?></td>
                                                <td><?php echo e($school->npsn); ?></td>
                                                <td><?php echo e($school->district->name); ?></td>
                                                <td><?php echo e($school->city->name); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('reporting.school.teacher', $school)); ?>" class="btn btn-sm btn-success">Data guru</a>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('reporting.school.show', $school)); ?>" class="btn btn-sm btn-info btn-rounded btn-sm"><i class="fas fa-eye"></i></a>
                                                    <a href="<?php echo e(route('reporting.school.print', $school)); ?>" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\projects\monev-tekkom\resources\views/reporting/index.blade.php ENDPATH**/ ?>