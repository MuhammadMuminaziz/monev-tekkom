<div class="container-fluid">
  <div class="row">
      <div class="col">
          <div class="card shadow py-3 border-bottom-primary">
              <div class="card-header">
                    <h6 class="m-0 font-weight-bold text-primary">Data Kecamatan</h6>
              </div>

              <div class="card-body">
                  <div class="table-responsive">
                        <div class="d-flex justify-content-between mb-4 ">
                            <button type="button" class="btn btn-primary my-2 rounded-pill" data-toggle="modal" data-target="#exampleModal"><i class="fas fa-plus-square"></i> Tambah Data</button>
                        </div>
                        <!-- Modal Tambah Data -->
                        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h6 class="modal-title font-weight-bold text-primary" id="exampleModalLabel"><i class="fas fa-plus-circle"></i> Data Kecamatan</h6>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form>
                                    <div class="form-group">
                                        <label for="" class="col-form-label">Nama Kota</label>
                                        <select wire:model="city_id" name="city_id" class="form-control" id="city_id">
                                            <option value="" selected>- Pilih Kota -</option>
                                            <option value="">...</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="message-text" class="col-form-label">Nama Desa/Kecamatan</label>
                                        <input wire:model="name" type="text" name="name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="" required>
                                    </div>
                                    </form>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button>
                                    <button type="button" class="btn btn-primary">Simpan Data</button>
                                </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Modal -->
                      <table class="table " id="dataTable" width="100%" cellspacing="0">
                          <thead>
                              <tr>
                                  <th width="5%">No</th>
                                  <th>Desa/Kecamatan</th>
                                  <th width="15%">Action</th>
                              </tr>
                          </thead>
                          <tbody>
                          <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($loop->iteration); ?></td>
                                  <td><?php echo e($district->name); ?></td>
                                  <td>
                                    <!-- <button wire:click="getDistrict(<?php echo e($district); ?>)" type="button"  class="btn btn-sm rounded btn-warning"><i class="fas fa-edit"></i></button>
                                    <button wire:click="destroy(<?php echo e($district); ?>)" type="button" class="btn btn-sm rounded btn-danger"><i class="fas fa-trash"></i></button> -->

                                      <a href="#" class="btn btn-sm btn-warning btn-rounded"><i class="fas fa-edit"></i></a>
                                      <form action="#" method="post" class="d-inline">
                                          <?php echo method_field('delete'); ?>
                                          <?php echo csrf_field(); ?>
                                          <button type="submit" class="btn btn-sm btn-danger btn-rounded">
                                              <i class="fas fa-trash"></i></button>
                                      </form>
                                  </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                  </div>
              </div>

              <!-- Edit data -->
                <div>
                    <div class="col-2">
                        <button type="button" class="btn btn-primary my-2 rounded-pill" data-toggle="modal" data-target="#exampleModal2">Edit Data</button>
                    </div>
                    <!-- Modal Edit Data -->
                    <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel2" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h6 class="modal-title font-weight-bold text-primary" id="exampleModalLabel2"><i class="fas fa-edit"></i> Data Kecamatan</h6>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form>
                                <div class="form-group">
                                    <label for="" class="col-form-label">Nama Kota</label>
                                    <select wire:model="city_id" name="city_id" class="form-control" id="city_id">
                                        <option value="" selected>- Pilih Kota -</option>
                                        <option value="">...</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="message-text" class="col-form-label">Nama Desa/Kecamatan</label>
                                    <input wire:model="name" type="text" name="name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name" placeholder="" required>
                                </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Kemabali</button>
                                <button type="button" class="btn btn-primary">Simpan Data</button>
                            </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Modal -->
                </div>
          </div>
      </div>
  </div>
</div>

<!-- <div class="p-3 mb-3">
    <?php if($isUpdate): ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('district.update', [])->html();
} elseif ($_instance->childHasBeenRendered('l625111204-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l625111204-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l625111204-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l625111204-0');
} else {
    $response = \Livewire\Livewire::mount('district.update', []);
    $html = $response->html();
    $_instance->logRenderedChild('l625111204-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php else: ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('district.create', [])->html();
} elseif ($_instance->childHasBeenRendered('l625111204-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l625111204-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l625111204-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l625111204-1');
} else {
    $response = \Livewire\Livewire::mount('district.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('l625111204-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <?php endif; ?>
    </div>
</div> --><?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/district/index.blade.php ENDPATH**/ ?>