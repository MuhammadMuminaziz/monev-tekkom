<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4 py-3 border-left-warning">
                <div class="card-body">
                    <h5 class="font-weight-bold text-warning">Data sedang di Verifikasi </h5>
                        <div class="form-group my-3">
                            <label for="">Terimakasih telah melakukan input Data Sekolah. Mohon tunggu, sedang dilakukan penintauan data. </label>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>



