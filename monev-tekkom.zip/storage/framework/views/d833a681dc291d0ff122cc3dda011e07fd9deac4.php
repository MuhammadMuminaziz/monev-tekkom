<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4 py-3">
                    <!-- <div class="card-header">
                        <h6 class="card-title font-weight-bold text-primary">Detail Data Sekolah</h6>
                    </div> -->
                    <div class="card-body">
                        <form action="">
                            <!-- Header -->
                            <div class="row justify-content-center">
                                <div class="col-md-12 m">
                                    <div class="text-center">
                                        <h4><strong> BALAI TEKNOLOGI KOMUNIKASI PENDIDIKAN PROVINSI MALUKU </strong>
                                        </h4>
                                        <h5>FORMAT PENDATAAN PENDIDIKAN BERBASIS TIK (DATA KETENAGAAN)</h5>
                                        <hr>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8 border mt-3 ">
                                    <div class="container my-3">
                                        <div class="table-responsive">
                                            <table class="table table-sm table-borderless">
                                                <tbody>
                                                    <tr>
                                                        <th class="my-5 font-weight-bold text-primary bg-light border-bottom p-2">
                                                            <h6><strong> A. Data Umum</strong></h6>
                                                        </th>
                                                    </tr>

                                                    <tr>
                                                        <th scope="row" class="col-md-5">Nama Guru / Tenaga Administrasi
                                                        </th>

                                                        <td class="col-md-7">: <?php echo e($teacher->teacher_name); ?></td>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Status Ketenagaan</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->employment_status); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">NIP</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->nip); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">NUPTK</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->nuptk); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Tempat, Tanggal Lahir</th>

                                                        <td class="col-md-7">:
                                                            <?php echo e($teacher->place_of_birth . ', ' . $teacher->date_of_birth); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Agama</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->religion); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Jenis Kelamin</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->gender); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Pendidikan Terakhir</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->last_education); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">TMT PNS</th>

                                                        <td>: <strong> Tahun :</strong> <?php echo e($teacher->tmt_pns_tahun); ?>

                                                            <strong> Bulan :</strong> <?php echo e($teacher->tmt_pns_bulan); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Pangkat / Golongan</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->class); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">TMT Golongan</th>

                                                        <td>: <strong> Tahun :</strong> <?php echo e($teacher->tmt_class_tahun); ?>

                                                            <strong> Bulan :</strong> <?php echo e($teacher->tmt_class_bulan); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Asal Sekolah</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->school->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Desa / Kecamatan</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->district->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Kabupaten / Kota</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->city->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Provinsi</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->provinsi); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">No Telpon/HP</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->phone); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5"></th>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <!-- Data Kompetensi -->
                                                    <tr>
                                                        <th
                                                            class="my-5 font-weight-bold text-primary bg-light border-bottom p-2">
                                                            <h6><strong> B. Data Kompetensi</strong></h6>
                                                        </th>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5"></th>
                                                        <td></td>
                                                        <td></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Mata pelajaran yang diampu</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->subjects_taught); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Program atau kegiatan yang
                                                            dilaksanakan</th>

                                                        <td> :
                                                            <?php $__currentLoopData = $teacher->program_teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($program->name . ' ,'); ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Status Sertifikasi</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->certification_status); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Tahun Sertifikasi</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->certification_year); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Alasan Belum Sertifikasi</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->reason_not_certified); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Kompetensi yang dimiliki</th>

                                                        <td> :
                                                            <?php $__currentLoopData = $teacher->competensi_teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competensi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($competensi->name . ' ,'); ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Kegiatan Sosialisasi UNBK</th>

                                                        <td class="col-md-7">:
                                                            <?php echo e($teacher->unbk_socialization_activities); ?>

                                                            <?php echo e($teacher->unbk_socialization_activities_tahun ? ', tahun ' . $teacher->unbk_socialization_activities_tahun : ''); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Keterlibatan dalam UNBK</th>

                                                        <td class="col-md-7">: <?php echo e($teacher->involvement_unbk); ?>

                                                            <?php echo e($teacher->involvement_unbk_tahun ? ', tahun ' . $teacher->involvement_unbk_tahun : ''); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Riwayat Keterlibatan dalam UNBK
                                                        </th>

                                                        <td class="col-md-7">: <?php echo e($teacher->history_involvement_unbk); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row" class="col-md-5">Kebutuhan Diklat saat ini</th>

                                                        <td>:
                                                            <?php $__currentLoopData = $teacher->training_need_nows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diklat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($diklat->name . ', '); ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th scope="row">Pelatihan Yang Pernah Diikuti</th>
                                                    </tr>
                                                    <tr>
                                                        <table class="table table-bordered">
                                                            <thead>
                                                                <tr class="text-center">
                                                                    <th>No</th>
                                                                    <th>Nama Diklat/Workshop/Seminar</th>
                                                                    <th>Tingkatan/Jenis Diklat</th>
                                                                    <th>Jampel</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php $__currentLoopData = $teacher->trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($loop->iteration); ?></td>
                                                                    <td><?php echo e($training->name); ?></td>
                                                                    <td><?php echo e($training->level); ?></td>
                                                                    <td><?php echo e($training->lesson_hours); ?></td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                                <!-- Kuisioner -->
                                <div class="col-md-4 border mt-3">
                                    <!-- <div class="container my-3"> -->
                                    <div class="table-responsive my-5">
                                        <table class="table-sm table-borderless">
                                            <tbody>
                                                <tr>
                                                    <th class="col-md-5"><small>Kode Kuisioner</small></th>

                                                    <td class="col-md-7"><small>:  <?php echo e($teacher->kode_kuisioner . '/B. TEKKOM/' . $teacher->tekkom . '/KR/2016'); ?></small>
                                                    </td>
                                                <tr>
                                                <tr>
                                                    <th class="col-md-5"><small>Tingkatan Sekolah</small></th>

                                                    <td class="col-md-7"><small>:
                                                            <?php echo e($teacher->tingkatan_sekolah); ?></small></td>
                                                <tr>
                                                <tr>
                                                    <th class="col-md-5"><small>Nama Petugas Pendataan</small></th>

                                                    <td class="col-md-7"><small>: <?php echo e($teacher->nama_petugas); ?></small>
                                                    </td>
                                                <tr>
                                                <tr>
                                                    <th class="col-md-5"><small>NIP</small></th>

                                                    <td class="col-md-7"><small>: <?php echo e($teacher->nip); ?></small></td>
                                                <tr>
                                                <tr>
                                                    <th class="align-top"><small>Range Waktu Pendataan</small></th>
                                                    <td class="align-top"><small>:
                                                            <?php echo e($teacher->range_waktu_dari); ?> <strong>s/d </strong> <?php echo e($teacher->range_waktu_sampai); ?></small>
                                                    </td>
                                                <tr>
                                                <tr class="text-center">
                                                    <th colspan="3"><small>Analisa Petugas Pendataan</small></th>
                                                <tr>
                                                    <td colspan="3"><small>
                                                            <textarea class="form-control"
                                                                id="exampleFormControlTextarea1"
                                                                rows="35"><?php echo e($teacher->analisis); ?></textarea></small>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <div class="table-responsive">
                                                        <table class="table  table-bordered">
                                                            <tr>
                                                                <td colspan="2" class="col-sm-6">
                                                                    <table class="table table-sm table-borderless">
                                                                        <tr>
                                                                            <td class="col-md-12 text-center"> <small>
                                                                                    Responden</small></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="col-md-12 text-center"><small>
                                                                                    tgl : <?php echo e($teacher->date_responden); ?>

                                                                                </small></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="col-md-12 text-center"><small>( <?php echo e($teacher->nama_responden); ?> )</small></td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                                <td colspan="2" class="col-sm-6 m-0">
                                                                    <table class="table table-sm table-borderless">
                                                                        <tr>
                                                                            <td class="col-md-12 text-center">
                                                                                <small>Petugas Pengumpul Data</small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="col-md-12 text-center"><small>tgl
                                                                                    :
                                                                                    <?php echo e($teacher->date_responden); ?></small>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td class="col-md-12 text-center"><small>(
                                                                                    <?php echo e($teacher->nama_petugas); ?>

                                                                                    )</small></td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- </div> -->
                                </div>
                            </div>
                            <div class="col-sm-12 my-3">
                                <a href="<?php echo e(route('teachers.index')); ?>" class="btn btn-secondary mr-2">Kembali</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\projects\monev-tekkom\resources\views/teacher/show.blade.php ENDPATH**/ ?>