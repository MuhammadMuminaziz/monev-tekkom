<x-app-layout>
    <livewire:city.index/>
</x-app-layout>