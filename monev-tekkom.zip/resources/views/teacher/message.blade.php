<x-app-layout>
    <div class="col-md-12">
        <div class="card mb-4 py-3 border-left-warning">
            <div class="card-body">

                <h5 class="font-weight-bold text-warning">Maaf Data Sekolah Tidak Tersedia
                </h5>
                <div class="form-group my-3">
                    <label for="">Untuk melakukan input data guru input data sekolah terlebih dahulu. </label>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>