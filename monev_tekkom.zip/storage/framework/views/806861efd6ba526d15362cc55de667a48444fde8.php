<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="card shadow p-3 text-dark">
                <div class="card-header bg-primary mb-2 text-white">
                    <div class="d-flex mb-2">
                        <h3>Nama Kecamatan</h3>
                    </div>

                    
                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert"
                        style="z-index: 99; top: 80px; right: 10px;">
                        <?php echo e(session('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>

                    <div class="p-3 mb-3">
                        <?php if($isUpdate): ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('district.update', [])->html();
} elseif ($_instance->childHasBeenRendered('l625111204-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l625111204-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l625111204-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l625111204-0');
} else {
    $response = \Livewire\Livewire::mount('district.update', []);
    $html = $response->html();
    $_instance->logRenderedChild('l625111204-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php else: ?>
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('district.create', [])->html();
} elseif ($_instance->childHasBeenRendered('l625111204-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l625111204-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l625111204-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l625111204-1');
} else {
    $response = \Livewire\Livewire::mount('district.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('l625111204-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="container-fluid mt-4">
                    <div class="table-responsive">
                        <table class="table table-hover table-sm" id="dataTable">
                            <thead>
                                <tr class="text-center">
                                    <th scope="col" width="50px">No</th>
                                    <th scope="col">Nama Kecamatan</th>
                                    <th scope="col" width="20%">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($district->name); ?></td>
                                    <td class="text-right">
                                        <button wire:click="getDistrict(<?php echo e($district); ?>)" type="button"
                                            class="btn btn-sm rounded btn-warning"><i class="fas fa-edit"></i></button>
                                        <button wire:click="destroy(<?php echo e($district); ?>)" type="button"
                                            class="btn btn-sm rounded btn-danger"><i class="fas fa-trash"></i></button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/district/index.blade.php ENDPATH**/ ?>