<div class="card p-3">
    <p class="text-center m-5">Maaf Anda belum mengimput data sekolah..</p>
    <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-sm btn-primary">Input data sekarang</a>
</div><?php /**PATH E:\projects\monev_tekkom\resources\views/components/school-no-data.blade.php ENDPATH**/ ?>