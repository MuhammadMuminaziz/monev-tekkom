<div class="container-fluid">
    <div class="row">
        <div class="col">
            <div class="card shadow border-bottom-primary">
                <div class="card-header py-3 mb-3">
                    <h6 class="m-0 font-weight-bold text-primary">Verifikasi Data Sekolah</h6>
                </div>
                <div class="card-body">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="home-tab" data-toggle="tab" data-target="#home"
                                type="button" role="tab" aria-controls="home" aria-selected="true">Permintaan
                                Verifikasi 
                                <span class="badge badge-primary"><?php echo e($schoolsVerify->count()); ?></span>
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="profile-tab" data-toggle="tab" data-target="#profile"
                                type="button" role="tab" aria-controls="profile" aria-selected="false">Data
                                Terverifikasi</button>
                        </li>
                    </ul>
                    <div class="tab-content my-4" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <!-- Belum Verifikasi Data Sekolah -->
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTableCheckBox" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="5%">No</th>
                                            <th>Nama Sekolah</th>
                                            <th>NPSN</th>
                                            <th>Kecamatan</th>
                                            <th>Kota</th>
                                            <th class="text-center">Status Verifikasi</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <?php $__currentLoopData = $schoolsVerify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($school->name); ?></td>
                                            <td><?php echo e($school->npsn); ?></td>
                                            <td><?php echo e($school->district->name); ?></td>
                                            <td><?php echo e($school->city->name); ?></td>
                                            <td class="text-center">
                                                <span class="badge badge-danger">Not Acitived</span>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('verifikator.schools.verify', $school)); ?>"
                                                    class="btn btn-sm btn-success">Verifikasi</a>
                                                <a href="<?php echo e(route('verifikator.schools.reject', $school)); ?>"
                                                    class="btn btn-sm btn-danger">Tolak</a>
                                                <a href="<?php echo e(route('verifikator.show', $school)); ?>"
                                                    class="btn btn-sm btn-info"><i class="fas fa-eye"></i></a>
                                            </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                            <!-- Sudah Verifikasi Data Sekolah -->
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th width="5%">No</th>
                                            <th>Nama Sekolah</th>
                                            <th>NPSN</th>
                                            <th>Kecamatan</th>
                                            <th>Kota</th>
                                            <th class="text-center">Status Verifikasi</th>
                                            <th class="text-center">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $schoolsActived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><?php echo e($school->name); ?></td>
                                            <td><?php echo e($school->npsn); ?></td>
                                            <td><?php echo e($school->district->name); ?></td>
                                            <td><?php echo e($school->city->name); ?></td>
                                            <td class="text-center">
                                                <span class="badge badge-success">Acitived</span>
                                            </td>
                                            <td class="text-center">
                                                <a href="<?php echo e(route('verifikator.show', $school)); ?>" class="btn btn-sm btn-info btn-rounded btn-sm"><i class="fas fa-eye"></i></a>
                                                
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\projects\monev-tekkom\resources\views/livewire/school/edit.blade.php ENDPATH**/ ?>