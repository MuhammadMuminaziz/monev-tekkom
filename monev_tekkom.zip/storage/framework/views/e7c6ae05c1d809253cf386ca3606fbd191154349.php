<div>
    <div class="row">
        <div class="col">
            <div class="card p-3">
                <div class="d-flex justify-content-between mb-2">
                    <h3>Users</h3>
                    <a href="" class="btn btn-sm px-4 pt-2 rounded-pill btn-outline-primary" data-toggle="modal" data-target="#exampleModal">Add new user</a>
                </div>
                <table class="table table-sm table-hover">
                    <thead>
                      <tr>
                        <th scope="col"></th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('user.store', [])->html();
} elseif ($_instance->childHasBeenRendered('l615171654-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l615171654-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l615171654-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l615171654-0');
} else {
    $response = \Livewire\Livewire::mount('user.store', []);
    $html = $response->html();
    $_instance->logRenderedChild('l615171654-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:user.store>
            </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/user/index.blade.php ENDPATH**/ ?>