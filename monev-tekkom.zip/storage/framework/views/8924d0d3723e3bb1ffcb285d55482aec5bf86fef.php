<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow mb-4 py-3 border-left-primary">
                    <div class="card-header">
                        <h6 class="card-title font-weight-bold text-primary">Tambah Data Guru</h6>
                    </div>
                    <div class="card-body">
                            <form action="<?php echo e(route('teachers.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group bg-light p-2 border-bottom row">
                                <h6><strong> A. Data Umum</strong></h6>
                            </div>
                                <div class="container mt-3">
                                    <div class="form-group row">
                                        <label for="teacher_name" class="col-sm-4 col-form-label">Nama Guru / Tenaga
                                            Administrasi</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['teacher_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="teacher_name" name="teacher_name" placeholder="" value="<?php echo e(old('teacher_name')); ?>">
                                            <?php $__errorArgs = ['teacher_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="employment_status" class="col-sm-4 col-form-label">Status Ketenagaan</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['employment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="employment_status" name="employment_status">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('employment_status') == 'PNS' ? 'selected' : ''); ?>>PNS</option>
                                                <option <?php echo e(old('employment_status') == 'NON PNS' ? 'selected' : ''); ?>>NON PNS</option>
                                            </select>
                                            <?php $__errorArgs = ['employment_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="nip" class="col-sm-4 col-form-label">NIP <br><small>(Diisi Jika
                                                PNS)</small></label>

                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nip" name="nip" value="<?php echo e(old('nip')); ?>" placeholder="">
                                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="nuptk" class="col-sm-4 col-form-label">NUPTK</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['nuptk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nuptk" name="nuptk" placeholder="" value="<?php echo e(old('nuptk')); ?>">
                                            <?php $__errorArgs = ['nuptk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="place_of_birth" class="col-sm-4 col-form-label">Tempat, Tanggal Lahir</label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control <?php $__errorArgs = ['place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="place_of_birth" name="place_of_birth" placeholder="" value="<?php echo e(old('place_of_birth')); ?>">
                                            <?php $__errorArgs = ['place_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <div class="input-group date" id="reservationdate"
                                                data-target-input="nearest">
                                                <input type="date" class="form-control <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>"/>
                                                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="religion" class="col-sm-4 col-form-label">Agama</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="religion" name="religion">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('religion') == 'Islam' ? 'selected' : ''); ?>>Islam</option>
                                                <option <?php echo e(old('religion') == 'Katolik' ? 'selected' : ''); ?>>Katolik</option>
                                                <option <?php echo e(old('religion') == 'Kristen' ? 'selected' : ''); ?>>Kristen</option>
                                                <option <?php echo e(old('religion') == 'Hindu' ? 'selected' : ''); ?>>Hindu</option>
                                                <option <?php echo e(old('religion') == 'Budha' ? 'selected' : ''); ?>>Budha</option>
                                            </select>
                                            <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div id="validationServer04Feedback" class="invalid-tooltip">
                                                Please select a valid state.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="gender" class="col-sm-4 col-form-label">Jenis Kelamin</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="gender" name="gender">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('gender') == 'Laki-laki' ? 'selected' : ''); ?> value="Laki-Laki">Laki-Laki</option>
                                                <option <?php echo e(old('gender') == 'Perempuan' ? 'selected' : ''); ?> value="Perempuan">Perempuan</option>
                                            </select>
                                            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="last_education" class="col-sm-4 col-form-label">Pendidikan Terakhir</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['last_education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="last_education" name="last_education">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('last_education') == 'SMA' ? 'selected' : ''); ?>>SMA</option>
                                                <option <?php echo e(old('last_education') == 'D1' ? 'selected' : ''); ?>>D1</option>
                                                <option <?php echo e(old('last_education') == 'D2' ? 'selected' : ''); ?>>D2</option>
                                                <option <?php echo e(old('last_education') == 'D3' ? 'selected' : ''); ?>>D3</option>
                                                <option <?php echo e(old('last_education') == 'D4' ? 'selected' : ''); ?>>D4</option>
                                                <option <?php echo e(old('last_education') == 'S1' ? 'selected' : ''); ?>>S1</option>
                                                <option <?php echo e(old('last_education') == 'S2' ? 'selected' : ''); ?>>S2</option>
                                                <option <?php echo e(old('last_education') == 'S3' ? 'selected' : ''); ?>>S3</option>
                                            </select>
                                            <?php $__errorArgs = ['last_education'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            <div id="validationServer04Feedback" class="invalid-tooltip">
                                                Please select a valid state.
                                            </div>

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tmt_pns_tahun" class="col-sm-4 col-form-label">TMT PNS</label>
                                        <div class="col-sm-4">
                                            <input type="number" class="form-control <?php $__errorArgs = ['tmt_pns_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tmt_pns_tahun" name="tmt_pns_tahun" value="<?php echo e(old('tmt_pns_tahun')); ?>" placeholder="Tahun">
                                            <?php $__errorArgs = ['tmt_pns_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- <div class="col-sm-1">
                                            Tahun
                                        </div> -->
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control <?php $__errorArgs = ['tmt_pns_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tmt_pns_bulan" name="tmt_pns_bulan" value="<?php echo e(old('tmt_pns_bulan')); ?>" placeholder="Bulan">
                                            <?php $__errorArgs = ['tmt_pns_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- <div class="col-sm-1">
                                            Bulan
                                        </div> -->
                                    </div>
                                    <div class="form-group row">
                                        <label for="class" class="col-sm-4 col-form-label">Pangkat / Golongan</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="class" name="class" placeholder="" value="<?php echo e(old('class')); ?>">
                                            <?php $__errorArgs = ['class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tmt_class_tahun" class="col-sm-4 col-form-label">TMT Golongan</label>
                                        <div class="col-sm-4">
                                            <input type="number" class="form-control <?php $__errorArgs = ['tmt_class_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tmt_class_tahun" name="tmt_class_tahun" value="<?php echo e(old('tmt_class_tahun')); ?>" placeholder="Tahun">
                                            <?php $__errorArgs = ['tmt_class_tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- <div class="col-sm-1">
                                            Tahun
                                        </div> -->
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control <?php $__errorArgs = ['tmt_class_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tmt_class_bulan" name="tmt_class_bulan" value="<?php echo e(old('tmt_class_bulan')); ?>" placeholder="Bulan">
                                            <?php $__errorArgs = ['tmt_class_bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <!-- <div class="col-sm-1">
                                            Bulan
                                        </div> -->
                                    </div>
                                    <div class="form-group row">
                                        <label for="school_id" class="col-sm-4 col-form-label">Asal Sekolah</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="school_id" name="school_id" placeholder="" value="<?php echo e($school->name ?? ''); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="district_id" class="col-sm-4 col-form-label">Desa / Kecamatan</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="district_id" class="form-control" id="district_id" value="<?php echo e($school->district->name); ?>" readonly>
                                            
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="city_id" class="col-sm-4 col-form-label">Kabupaten / Kota</label>
                                        <div class="col-sm-8">
                                            <input type="text" name="city_id" class="form-control" id="city_id" value="<?php echo e($school->city->name); ?>" readonly>
                                            
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="provinsi" class="col-sm-4 col-form-label">Provinsi</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="provinsi" value="Maluku" readonly name="provinsi" placeholder="">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="phone" class="col-sm-4 col-form-label">No Telpon/HP</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="phone" name="phone" placeholder="" value="<?php echo e(old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group bg-light border-bottom p-2 row">
                                    <h6><strong> B. Data Kompetensi</strong></h6>
                                </div>
                                <div class="container mt-3">
                                    <div class="form-group row">
                                        <label for="subjects_taught" class="col-sm-4 col-form-label">Mata Pelajaran Yang
                                            Diampu</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['subjects_taught'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subjects_taught" name="subjects_taught" placeholder="" value="<?php echo e(old('subjects_taught')); ?>">
                                            <?php $__errorArgs = ['subjects_taught'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="program" class="col-sm-4 col-form-label">Program / Kegiatan Yang
                                            Dilaksanakan</label>
                                        <div class="col-sm-8 page-input-program">
                                            <input type="text" class="form-control mb-2" id="program" name="program[]" placeholder="" multiple>
                                        </div>
                                    </div>
                                    <div class="row justify-content-end mx-3 mb-3">
                                        <small class="text-primary add-input-program mr-2" style="cursor: pointer;">tambah data |</small>
                                        <small class="text-danger remove-input-program" style="cursor: pointer;">Hapus data</small>
                                    </div>
                                    <div class="form-group row">
                                        <label for="certification_status" class="col-sm-4 col-form-label">Status Sertifikasi</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['certification_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="certification_status" name="certification_status">
                                                <option selected disabled>Pilih</option>
                                                <option <?php echo e(old('certification_status' == 'Sudah' ? 'selected' : '')); ?>>Sudah</option>
                                                <option <?php echo e(old('certification_status' == 'Belum' ? 'selected' : '')); ?>>Belum</option>
                                            </select>
                                            <?php $__errorArgs = ['certification_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="certification_year" class="col-sm-4 col-form-label">Tahun Sertifikasi</label><br>
                                        <div class="col-sm-6">
                                            <input type="number" class="form-control" id="certification_year" name="certification_year" value="<?php echo e(old('certification_year')); ?>" placeholder=""> <br>
                                        </div>
                                        <div class="col-sm-2">
                                            <small>*(diisi jika sudah sertifikasi)</small>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <label for="reason_not_certified" class="col-form-label">Alasan Belum
                                                Sertifikasi</label><br>
                                            <small>*(diisi jika sudah sertifikasi tidak perlu diisi)</small>
                                        </div>
                                        <div class="col-sm-8">
                                            <textarea class="form-control <?php $__errorArgs = ['reason_not_certified'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="reason_not_certified" name="reason_not_certified"
                                                rows="6"><?php echo e(old('reason_not_certified')); ?></textarea>
                                                <?php $__errorArgs = ['reason_not_certified'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="competencies_taught" class="col-sm-4 col-form-label">Kompetensi Yang
                                            Dimiliki</label>
                                        <div class="col-sm-8">
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="world" name="competencies_taught[]"
                                                    value="Ms. Word" multiple>
                                                <label class="form-check-label" for="world">Ms.
                                                    Word</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="excel" name="competencies_taught[]"
                                                    value="Ms. Excel">
                                                <label class="form-check-label" for="excel">Ms.
                                                    Excel</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="ppt" name="competencies_taught[]"
                                                    value="Power Point">
                                                <label class="form-check-label" for="ppt">Power
                                                    Point</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="photo" name="competencies_taught[]"
                                                    value="Photoshop" multiple>
                                                <label class="form-check-label" for="photo">Photoshop</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="animasi" name="competencies_taught[]"
                                                    value="Animasi" multiple>
                                                <label class="form-check-label" for="animasi">Animasi</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="programmer" name="competencies_taught[]"
                                                    value="Programmer" multiple>
                                                <label class="form-check-label" for="programmer">Programmer</label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="jaringan" name="competencies_taught[]"
                                                    value="Jaringan" multiple>
                                                <label class="form-check-label" for="jaringan">Jaringan</label>
                                            </div>
                                            <input type="text" class="form-control form-control-sm" id="" name="competencies_taught_n"
                                                placeholder="Lainnya" multiple>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="unbk_socialization_activities" class="col-sm-4 col-form-label">Kegiatan Sosialisasi
                                            UNBK</label>
                                        <div class="col-sm-4">
                                            <select class="custom-select <?php $__errorArgs = ['unbk_socialization_activities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="unbk_socialization_activities" name="unbk_socialization_activities">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('unbk_socialization_activities') == 'Sudah' ? 'selected' : ''); ?>>Sudah</option>
                                                <option <?php echo e(old('unbk_socialization_activities') == 'Belum' ? 'selected' : ''); ?>>Belum</option>
                                            </select>
                                            <?php $__errorArgs = ['unbk_socialization_activities'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="number" class="form-control" id="#" name="unbk_socialization_activities_tahun" placeholder="Tahun" value="<?php echo e(old('unbk_socialization_activities_tahun')); ?>">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="involvement_unbk" class="col-sm-4 col-form-label">Keterlibatan dalam
                                            UNBK</label>
                                        <div class="col-sm-4">
                                            <select class="custom-select <?php $__errorArgs = ['involvement_unbk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="involvement_unbk" name="involvement_unbk">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('involvement_unbk') == 'Sudah' ? 'selected' : ''); ?>>Sudah</option>
                                                <option <?php echo e(old('involvement_unbk') == 'Belum' ? 'selected' : ''); ?>>Belum</option>
                                            </select>
                                            <?php $__errorArgs = ['involvement_unbk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="number" class="form-control" id="involvement_unbk" value="<?php echo e(old('involvement_unbk_tahun')); ?>" name="involvement_unbk_tahun" placeholder="Tahun">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <div class="col-sm-4">
                                            <label for="history_involvement_unbk" class="col-form-label">Riwayat Keterlibatan Dalam
                                                UNBK</label><br>
                                            <small> *(jika telah melaksanakan UNBK)</small>
                                        </div>
                                        <div class="col-sm-8">
                                            <textarea class="form-control <?php $__errorArgs = ['history_involvement_unbk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invaild <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="history_involvement_unbk" name="history_involvement_unbk"
                                                rows="6"><?php echo e(old('history_involvement_unbk')); ?></textarea>
                                                <?php $__errorArgs = ['history_involvement_unbk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="" class="col-sm-12 col-form-label"><strong> Pelatihan Yang
                                                Pernah
                                                Diikuti</strong></label>
                                    </div>
                                    <div class="page-input-training">
                                        <div class="form-row">
                                            <div class="form-group col-md-5">
                                                <label for="name_of_training">Nama Diklat/Workshop/Seminar</label>
                                                <input type="text" class="form-control" id="name_of_training"
                                                    name="name_of_training[]" multiple>
                                            </div>
                                            <div class="form-group col-md-3">
                                                <label for="level">Tingkatan/Jenis Diklat</label>
                                                <select id="level" name="level[]" class="custom-select">
                                                    <option selected>Pilih</option>
                                                    <option <?php echo e(old('level') == 'Pemula' ? 'selected' : ''); ?>>Pemula</option>
                                                    <option <?php echo e(old('level') == 'Lanjutan' ? 'selected' : ''); ?>>Lanjutan</option>
                                                    <option <?php echo e(old('level') == 'Mahir' ? 'selected' : ''); ?>>Mahir</option>
                                                </select>
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="jampel">Jampel</label>
                                                <input type="text" class="form-control mb-2" id="jampel" name="jampel[]" multiple>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mx-3 mb-2 justify-content-end">
                                        <small class="text-primary add-input-training mr-2" style="cursor: pointer;">tambah data |</small>
                                        <small class="text-danger remove-input-training" style="cursor: pointer;">hapus data</small>
                                    </div>
                                    <div class="form-group row">
                                        <label for="training_needs_now" class="col-sm-4 col-form-label">Kebutuhan Diklat Saat
                                            Ini</label>
                                        <div class="col-sm-12 page-input-training-needs">
                                            <input type="text" class="form-control mb-2" id="training_needs_now" name="training_needs_now[]" multiple>
                                        </div>
                                        <div class="col-sm-12 d-flex px-4 mt-3 justify-content-end">
                                            <small class="add-input-training-needs text-primary mr-2" style="cursor: pointer;">tambah data |</small>
                                            <small class="remove-input-training-needs text-danger" style="cursor: pointer;">hapus data</small>
                                        </div>
                                    </div>       
                                </div>

                                <div class="container mt-3">
                                    <div class="form-group row">
                                        <label for="kode_kuisioner" class="col-sm-4 col-form-label">Kode Kuisioner</label>
                                        <div class="col-sm-1">
                                            <input type="text" class="form-control <?php $__errorArgs = ['kode_kuisioner'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="kode_kuisioner" name="kode_kuisioner" placeholder="" value="<?php echo e(old('kode_kuisioner')); ?>">
                                        </div>
                                        <div class="col-sm-1">
                                            <label for="tekkom" class="col-form-label">/B.Tekkom/</label>
                                        </div>
                                        <div class="col-sm-1">
                                            <input type="text" class="form-control <?php $__errorArgs = ['tekkom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tekkom" name="tekkom" placeholder="" value="<?php echo e(old('tekkom')); ?>">
                                        </div>
                                        <div class="col-sm-1">
                                            <label for="#" class="col-form-label">/KR/2016</label>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="tingkatan_sekolah" class="col-sm-4 col-form-label">Tingkatan Sekolah</label>
                                        <div class="col-sm-8">
                                            <select class="custom-select <?php $__errorArgs = ['tingkatan_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="tingkatan_sekolah" name="tingkatan_sekolah">
                                                <option selected disabled value="">Pilih</option>
                                                <option <?php echo e(old('tingkatan_sekolah') == 'SD' ? 'selected' : ''); ?>>SD</option>
                                                <option <?php echo e(old('tingkatan_sekolah') == 'SMP' ? 'selected' : ''); ?>>SMP</option>
                                                <option <?php echo e(old('tingkatan_sekolah') == 'SMA' ? 'selected' : ''); ?>>SMA</option>
                                                <option <?php echo e(old('tingkatan_sekolah') == 'SMK' ? 'selected' : ''); ?>>SMK</option>
                                            </select>
                                            <?php $__errorArgs = ['tingkatan_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="nama_petugas" class="col-sm-4 col-form-label">Nama Petugas Pendataan</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control" id="nama_petugas" value="<?php echo e(auth()->user()->name); ?>" name="nama_petugas" placeholder="" readonly>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="nip" class="col-sm-4 col-form-label">NIP</label>
                                        <div class="col-sm-8">
                                            <input type="text" class="form-control <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nip" name="nip" placeholder="" value="<?php echo e(old('nip')); ?>">
                                            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="range_waktu_dari" class="col-sm-4 col-form-label">Range Waktu Pendataan</label>
                                        <div class="col-sm-4">
                                            <input type="date" class="form-control <?php $__errorArgs = ['range_waktu_dari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="range_waktu_dari" name="range_waktu_dari" placeholder="" value="<?php echo e(old('range_waktu_dari')); ?>">
                                            <?php $__errorArgs = ['range_waktu_dari'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="date" class="form-control <?php $__errorArgs = ['range_waktu_sampai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="range_waktu_sampai" name="range_waktu_sampai" placeholder="" value="<?php echo e(old('range_waktu_sampai')); ?>">
                                            <?php $__errorArgs = ['range_waktu_sampai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="analisis" class="col-sm-4 col-form-label">Analisa Petugas Pendataan</label>
                                        <div class="col-sm-8">
                                            <textarea class="form-control <?php $__errorArgs = ['analisis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="analisis" name="analisis" rows="8"><?php echo e(old('analisis')); ?></textarea>
                                            <?php $__errorArgs = ['analisis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="nama_responden" class="col-sm-4 col-form-label">Responden</label>
                                        <div class="col-sm-4">
                                            <input type="text" class="form-control <?php $__errorArgs = ['nama_responden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="nama_responden" name="nama_responden" placeholder="Nama Responden" value="<?php echo e(old('nama_responden')); ?>">
                                            <?php $__errorArgs = ['nama_responden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-sm-4">
                                            <input type="date" class="form-control <?php $__errorArgs = ['date_responden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="" name="date_responden" value="<?php echo e(old('date_responden')); ?>" placeholder="">
                                            <?php $__errorArgs = ['date_responden'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback">
                                                <?php echo e($message); ?>

                                            </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 my-5">
                                        <button type="submit" class="btn btn-primary float-right">Simpan Data</button>
                                        <a href="<?php echo e(route('teachers.index')); ?>"
                                            class="btn btn-secondary float-right mr-2">Kembali</a>
                                    </div>
                                    <br><br><br><hr>
                                    <div class="form-group row">
                                        <small><strong><i class="fas fa-file-alt"></i> Catatan</strong></small>
                                        <small class="col-sm-12 text-muted well well-sm no-shadow ">
                                        Untuk kode kuisioner diisi dengan nomor urut dan kode kabupaten/kota : <br>
                                        1.Kota Ambon, 2.Kota Tual, 3.Maluku tengah, 4.SBB, 5.SBT, 6.Butu, 7.Buru Selatan, 8.Maluku Tenggara, 9.Maluku Barat, 10.Maluku Barat Daya, 11.Kep.Aru
                                        </small>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /.card-body -->

                </div>
                <!-- /.card -->
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\projects\monev-tekkom\resources\views/teacher/create.blade.php ENDPATH**/ ?>