
  
  

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h3 class="text-center text-warning">Attention...</h3>
        </div>
        <div class="card-body text-center">
            <p class="mb-5">Maaf Anda Belum mempunyai data sekolah...</p>
            <a href="<?php echo e(route('schools.create')); ?>" class="btn btn-primary">Input data sekolah</a>
        </div>
    </div>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/components/school-no-data.blade.php ENDPATH**/ ?>