<div>
    <form wire:submit.prevent="store">
        <input wire:model="district_id" type="hidden">
        <div class="form-group mb-2">
            <select wire:model="city_id" name="city_id" class="form-control" id="city_id">
                <option value="" selected disabled>pilih kota</option>
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group mb-3">
            <input wire:model="name" type="text" name="name" class="form-control rounded-pill <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                placeholder="masukan nama kecamatan" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="d-flex justify-content-end mb-4">
            <button type="submit" class="btn btn-sm px-4 btn-secondary rounded-pill mr-1">update district</button>
            <button wire:click="censelUpdate()" type="button" class="btn btn-sm px-4 btn-danger rounded-pill">censel</button>
        </div>
    </form>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/district/update.blade.php ENDPATH**/ ?>