<div class="card p-5">
    <h1>Data anda sedang di tinjau... Harap tunggu.</h1>
</div><?php /**PATH E:\projects\monev_tekkom\resources\views/components/school-no-verify.blade.php ENDPATH**/ ?>