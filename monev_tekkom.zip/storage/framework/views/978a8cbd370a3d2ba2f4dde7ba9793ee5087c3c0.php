<form action="<?php echo e(route('district.update', $district)); ?>" method="post">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <div class="modal-body">
        <div class="form-group">
            <label for="" class="col-form-label">Nama Kota</label>
            <select name="city_id" class="form-control" id="city_id">
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($city->name == $district->city->name): ?>
                    <option selected value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php else: ?>
                    <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="message-text" class="col-form-label">Nama Desa/Kecamatan</label>
            <input type="text" name="name" class="form-control" id="name" value="<?php echo e(old('name', $district->name)); ?>" placeholder="" required>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Kemabali</button>
        <button type="submit" class="btn btn-primary">Simpan Data</button>
    </div>
</form><?php /**PATH E:\projects\monev_tekkom\resources\views/district/edit.blade.php ENDPATH**/ ?>