<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                
                     <!-- Data sedang di Tinjau -->
                    <?php if($school->isActive == 0): ?>
                    <div class="col-md-12">
                        <div class="card mb-4 py-3 border-left-warning">
                            <div class="card-body">
                                <h5 class="font-weight-bold text-warning">Data Sekolah Sedang di Verifikasi
                                </h5>
                                <div class="form-group my-3">
                                    <label for="">Untuk melakukan input data guru mohon tunggu proses verifikasi data sekolah. </label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                      <!-- Data ditolak -->
                    <?php if($school->isActive == 2): ?>
                    <div class="col-md-6">
                        <div class="card mb-4 py-3 border-left-danger">
                            <div class="card-body">
                                <h5 class="font-weight-bold text-danger">Verifikasi Data Sekolah di Tolak!</h5>
                                <div class="form-group my-3">
                                    <label for="">Mohon periksa kembali data sekolah agar dapat melakukan input data Guru</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                <!-- Add Data -->
                <?php if($school->isActive == 1): ?>
                <div class="card shadow border-bottom-primary">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Data Guru</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <a href="<?php echo e(route('teachers.create')); ?>"
                                class="btn btn-sm px-3 pt-2 mb-3 rounded-pill btn-primary"><i class="fas fa-plus-square"></i>
                                Tambah Data</a>
                            <table class="table " id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th width="5%">No</th>
                                        <th>Nama Guru</th>
                                        <th>NUPTK</th>
                                        <th>Asal Sekolah</th>
                                        <th>Kecamatan</th>
                                        <th>Kota</th>
                                        <th class="text-center">Status</th>
                                        <th width="15%" class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($teacher->teacher_name); ?></td>
                                        <td><?php echo e($teacher->nuptk); ?></td>
                                        <td><?php echo e($teacher->school->name); ?></td>
                                        <td><?php echo e($teacher->district->name); ?></td>
                                        <td><?php echo e($teacher->city->name); ?></td>
                                        <td class="text-center">
                                            <?php if($teacher->isActive == 0): ?>
                                            <span class="badge badge-danger">Not Acitived</span>
                                            <?php else: ?>
                                            <span class="badge badge-success">Acitived</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('teachers.show', $teacher)); ?>" class="btn btn-sm btn-info btn-rounded btn-sm"><i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('teachers.edit', $teacher)); ?>" class="btn btn-sm btn-warning btn-rounded btn-sm"><i class="fas fa-edit"></i></a>
                                           
                                            <form action="<?php echo e(route('teachers.destroy', $teacher)); ?>" method="post"
                                                class="d-inline">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="d-none"></button>
                                                    <a href="" class="btn btn-sm btn-danger btn-rounded not-link confirm-delete"><i class="fas fa-trash"></i></a>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\projects\monev-tekkom\resources\views/teacher/index.blade.php ENDPATH**/ ?>