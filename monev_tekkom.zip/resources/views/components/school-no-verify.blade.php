<div class="card p-5">
    <h1>Data anda sedang di tinjau... Harap tunggu.</h1>
</div>