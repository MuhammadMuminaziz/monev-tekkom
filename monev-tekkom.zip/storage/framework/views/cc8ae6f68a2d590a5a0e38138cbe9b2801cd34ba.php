<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($loop->iteration); ?></td>
    <td><?php echo e($school->name); ?></td>
    <td><?php echo e($school->npsn); ?></td>
    <td><?php echo e($school->district->name); ?></td>
    <td><?php echo e($school->city->name); ?></td>

    <td><a href="<?php echo e(route('reporting.school.teacher', $school)); ?>" class="btn btn-sm btn-success">Data guru</a></td>
    <td>
        <a href="<?php echo e(route('reporting.school.show', $school)); ?>" class="btn btn-sm btn-info btn-rounded btn-sm"><i
                class="fas fa-eye"></i></a>
        <a href="#" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</a>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\projects\monev-tekkom\resources\views/reporting/table-school.blade.php ENDPATH**/ ?>