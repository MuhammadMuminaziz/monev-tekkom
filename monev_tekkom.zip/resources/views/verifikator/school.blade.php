<x-app-layout>
    <livewire:school.edit/>
</x-app-layout>