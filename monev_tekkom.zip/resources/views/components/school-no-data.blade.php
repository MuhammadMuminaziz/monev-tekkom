<div class="card p-3">
    <p class="text-center m-5">Maaf Anda belum mengimput data sekolah..</p>
    <a href="{{ route('schools.create') }}" class="btn btn-sm btn-primary">Input data sekarang</a>
</div>