<div id="wrapper">
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
        
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
            <div class="sidebar-brand-icon rotate-n-15">
                <i class="fas fa-laugh-wink"></i>
            </div>
            <div class="sidebar-brand-text mx-3">Monev Tekkom</div>
        </a>

        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('owner')): ?>
        <!-- Nav Item - Dashboard -->
        <li class="nav-item <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('dashboard')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Dashboard</span></a>
        </li>
        
        <li class="nav-item <?php echo e(request()->is('reporting') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('reporting.index')); ?>">
                <i class="fas fa-fw fa-tachometer-alt"></i>
                <span>Reporting</span></a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('operator')): ?>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <li class="nav-item <?php echo e(request()->is('schools*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('schools.index')); ?>">
            <i class="fas fa-school"></i>
                <span>Scools</span></a>
        </li>

        <li class="nav-item <?php echo e(request()->is('teachers*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('teachers.index')); ?>">
            <i class="fas fa-chalkboard-teacher"></i>
                <span>Teachers</span></a>
        </li>
        <?php endif; ?>
        
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('super_admin')): ?>
            <!-- Divider -->
        <hr class="sidebar-divider my-0">
        
        <li class="nav-item <?php echo e(request()->is('cities*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('cities.index')); ?>">
            <i class="fas fa-city"></i>
                <span>Cities</span></a>
        </li>
        
        <li class="nav-item <?php echo e(request()->is('district*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('district.index')); ?>">
            <i class="fas fa-cube"></i>
                <span>District</span></a>
        </li>

        <li class="nav-item <?php echo e(request()->is('school*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('school.index')); ?>">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Scools</span></a>
        </li>

        <li class="nav-item <?php echo e(request()->is('users*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('users.index')); ?>">
            <i class="fas fa-users"></i>
                <span>Users</span></a>
        </li>
        
        <li class="nav-item <?php echo e(request()->is('periode*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('periode.index')); ?>">
                <i class="fas fa-fw fa-table"></i>
                <span>Periode active</span></a>
        </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('verifikator')): ?>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">

        <li class="nav-item <?php echo e(request()->is('schools*') ? 'active' : ''); ?>">
            <a class="nav-link pb-0" href="<?php echo e(route('verifikator.schools')); ?>">
                <i class="fas fa-fw fa-chart-area"></i>
                <span>Scools</span></a>
        </li>

        <li class="nav-item <?php echo e(request()->is('teachers*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('verifikator.teachers')); ?>">
                <i class="fas fa-fw fa-table"></i>
                <span>Teachers</span></a>
        </li>
        <?php endif; ?>

        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

    </ul>
</div><?php /**PATH E:\projects\monev_tekkom\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>