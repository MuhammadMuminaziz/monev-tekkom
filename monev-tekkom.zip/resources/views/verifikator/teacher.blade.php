<x-app-layout>
    <livewire:teacher.edit/>
</x-app-layout>