<?php return array (
  'city.create' => 'App\\Http\\Livewire\\City\\Create',
  'city.index' => 'App\\Http\\Livewire\\City\\Index',
  'city.update' => 'App\\Http\\Livewire\\City\\Update',
  'district.create' => 'App\\Http\\Livewire\\District\\Create',
  'district.index' => 'App\\Http\\Livewire\\District\\Index',
  'district.update' => 'App\\Http\\Livewire\\District\\Update',
  'school.edit' => 'App\\Http\\Livewire\\School\\Edit',
  'teacher.edit' => 'App\\Http\\Livewire\\Teacher\\Edit',
);