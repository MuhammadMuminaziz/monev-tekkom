<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card shadow">
                <div class="card-header">
                    <h6 class="card-title">Edit Data Guru</h6>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <form action="<?php echo e(route('teachers.update', $teacher)); ?>" method="post">
                    <div class="row">
                            <?php echo method_field('put'); ?>
                            <!-- Data Umum -->
                            <div class="col-md-6">
                                A. Data Umum
                                <div class="form-group">
                                    <label for="teacher_name">Nama Guru / Tenaga Administrasi</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="teacher_name" name="teacher_name" value="<?php echo e(old('teacher_name', $teacher->teacher_name)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="employment_status">Status Ketenagaan</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="employment_status" name="employment_status" value="<?php echo e(old('employment_status', $teacher->employment_status)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="nip">NIP</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="nip" name="nip" value="<?php echo e(old('nip', $teacher->nip)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="nuptk">NUPTK</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="nuptk" name="nuptk" value="<?php echo e(old('nuptk', $teacher->nuptk)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="place_of_birth">Tempat Lahir</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="place_of_birth" name="place_of_birth" value="<?php echo e(old('place_of_birth', $teacher->place_of_birth)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="date_of_birth">Tanggal Lahir</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="date_of_birth" name="date_of_birth" value="<?php echo e(old('date_of_birth', $teacher->date_of_birth)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="religion">Agama</label>
                                    <div class="col-sm-12">
                                        <select class="custom-select" id="religion" name="religion">
                                            <option selected disabled value=""><?php echo e($teacher->religion); ?></option>
                                            <option>Islam</option>
                                            <option>Katolik</option>
                                            <option>Kristen</option>
                                            <option>Hindu</option>
                                            <option>Budha</option>
                                            <option>Lainnya</option>
                                        </select> </div>
                                </div>
                                <div class="form-group">
                                    <label>Jenis Kelamin</label>
                                    <div class="col-sm-12">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="gender"
                                                id="laki-laki" value="Laki-laki" <?php echo e($teacher->gender == 'Laki-laki' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="laki-laki">Laki-laki</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="gender"
                                                id="perempuan" value="Perempuan" <?php echo e($teacher->gender == 'Perempuan' ? 'checked' : ''); ?>>
                                            <label class="form-check-label" for="perempuan">Perempuan</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="last_education">Pendidikan Terakhir</label>
                                    <div class="col-sm-12">
                                        <select class="custom-select" id="last_education" name="last_education">
                                            <option selected disabled value=""><?php echo e($teacher->last_education); ?></option>
                                            <option>SMA</option>
                                            <option>D1</option>
                                            <option>D2</option>
                                            <option>D3</option>
                                            <option>D4</option>
                                            <option>S1</option>
                                            <option>S2</option>
                                            <option>S3</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tmt_pns_tahun">TMT PNS TAHUN</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="tmt_pns_tahun" name="tmt_pns_tahun" value="<?php echo e(old('tmt_pns_tahun', $teacher->tmt_pns_tahun)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tmt_pns_bulan">TMT PNS BULAN</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="tmt_pns_bulan" name="tmt_pns_bulan" value="<?php echo e(old('tmt_pns_bulan', $teacher->tmt_pns_bulan)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="class">Pangkat / Golongan</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="class" name="class" value="<?php echo e(old('class', $teacher->class)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tmt_class_tahun">TMT Golongan Tahun</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="tmt_class_tahun" name="tmt_class_tahun" value="<?php echo e(old('tmt_class_tahun', $teacher->tmt_class_tahun)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="tmt_class_bulan">TMT Golongan Bulan</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="tmt_class_bulan" name="tmt_class_bulan" value="<?php echo e(old('tmt_class_bulan', $teacher->tmt_class_bulan)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="School_Origin">Asal Sekolah</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="School_Origin" name="School_Origin" value="<?php echo e(old('School_Origin', $teacher->School_Origin)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="district_id">Desa / Kecamatan</label>
                                    <div class="col-sm-12">
                                        <select name="district_id" class="form-control" id="district_id">
                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($district->name == $teacher->district->name): ?>
                                            <option selected value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($district->id); ?>"><?php echo e($district->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="city_id">Desa / Kecamatan</label>
                                    <div class="col-sm-12">
                                        <select name="city_id" class="form-control" id="city_id">
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($city->name == $teacher->city->name): ?>
                                            <option selected value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                            <?php else: ?>
                                            <option value="<?php echo e($city->id); ?>"><?php echo e($city->name); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label>Propinsi</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="#" placeholder="" readonly value="<?php echo e($teacher->provinsi); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="phone">No Telpon/HP</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $teacher->phone)); ?>" placeholder="">
                                    </div>
                                </div>





                            </div>
                            <!--  Data Kompetensi -->
                            <div class="col-md-6">
                                Data Kompetensi
                                <div class="form-group">
                                    <label for="subjects_taught">Mata pelajaran yang diampu</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="subjects_taught" name="subjects_taught" value="<?php echo e(old('subjects_taught', $teacher->subjects_taught)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="program">Program atau kegiatan yang
                                                dilaksanakan</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="program" name="program" value="<?php echo e(old('program', $teacher->program)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="certification_status">Status Sertifikasi</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="certification_status" name="certification_status" value="<?php echo e(old('certification_status', $teacher->certification_status)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="certification_year">Tahun Sertifikasi</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="certification_year" name="certification_year" value="<?php echo e(old('certification_year', $teacher->certification_year)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="reason_not_certified">Alasan Belum Sertifikasi</label>
                                    <div class="col-sm-12">
                                    <input type="text" class="form-control" id="reason_not_certified" name="reason_not_certified" value="<?php echo e(old('reason_not_certified', $teacher->reason_not_certified)); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="competencies_taught">Kompetensi yang dimiliki</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="competencies_taught" name="competencies_taught" value="<?php echo e(old('competencies_taught', $teacher->competencies_taught)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="unbk_socialization_activities">Kegiatan Sosialisasi UNBK</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="unbk_socialization_activities" name="unbk_socialization_activities" value="<?php echo e(old('unbk_socialization_activities', $teacher->unbk_socialization_activities)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="involvement_unbk">Keterlibatan dalam UNBK</label>
                                    <div class="col-sm-12">
                                        <input type="text" class="form-control" id="involvement_unbk" name="involvement_unbk" value="<?php echo e(old('involvement_unbk', $teacher->involvement_unbk)); ?>" placeholder="">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="history_involvement_unbk">Riwayat Keterlibatan dalam UNBK</label>
                                    <div class="col-sm-12">
                                    <input type="text" class="form-control" id="history_involvement_unbk" name="history_involvement_unbk" value="<?php echo e(old('history_involvement_unbk', $teacher->history_involvement_unbk)); ?>">
                                    </div>
                                </div>
                                Data Diklat
                                <div class="form-group">
                                    <label for="name_of_training">Nama Diklat/Workshop/Seminar</label>
                                    <div class="col-sm-12">
                                        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="text" class="form-control" id="name_of_training" name="name_of_training[]" value="<?php echo e($training->name); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="level">Tingkatan/Jenis Diklat</label>
                                    <div class="col-sm-12">
                                    <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <select name="level[]" id="level" class="form-control">
                                        <option selected value="<?php echo e($training->level); ?>"><?php echo e($training->level); ?></option>
                                        <option value="Pemula">Pemula</option>
                                        <option value="Lanjutan">Lanjutan</option>
                                        <option value="Mahir">Pemula</option>
                                    </select>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="form-group">
                                    <label for="jampel">Jampel</label>
                                    <div class="col-sm-12">
                                        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="text" class="form-control" id="jampel" name="jampel[]" value="<?php echo e($training->lesson_hours); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="training_needs_now">Kebutuhan Diklat saat ini</label>
                                    <div class="col-sm-12">
                                        <?php $__currentLoopData = $training_needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training_need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="text" class="form-control" id="training_needs_now" name="training_needs_now[]" value="<?php echo e($training_need->name); ?>">
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Update Data</button>
                            </div>
                            <!-- /.col -->
                            <?php echo csrf_field(); ?>
                        </div>
                    </form>
                    <!-- /.row -->
                </div>
                <!-- /.card-body -->

            </div>
        </div>
    </div>
</div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\projects\monev_tekkom\resources\views/teacher/edit.blade.php ENDPATH**/ ?>