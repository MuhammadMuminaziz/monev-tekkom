<div class="card p-5">
    <h1>Data anda Berhasil di verifikasi</h1>
    <a href="{{ route('schools.show', $school) }}" class="btn btn-sm btn-success">Lihat Data</a>
</div>