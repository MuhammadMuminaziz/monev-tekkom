<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <!-- Data Sekolah -->
        <div class="row">
            <div class="col-md-6">
                <div class="card shadow mb-4  border-left-primary">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Sekolah</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-group ">
                            <table class="w-100">
                                <tr>
                                    <th>Nama Sekolah</th>
                                    <td>:</td>
                                    <td><?php echo e($school->name); ?></td>
                                </tr>
                                <tr>
                                    <th>NPSN</th>
                                    <td>:</td>
                                    <td><?php echo e($school->npsn); ?></td>
                                </tr>
                                <tr>
                                    <th>Kecamatan</th>
                                    <td>:</td>
                                    <td><?php echo e($school->district->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Kab/Kota</th>
                                    <td>:</td>
                                    <td><?php echo e($school->city->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Jumlah Guru</th>
                                    <td>:</td>
                                    <td><?php echo e($school->teachers->count()); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Data Guru by Sekolah -->
        <div class="row">
            <div class="col">
                <div class="card shadow border-bottom-primary">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Data Guru </h6>
                    </div>
                    <div class="card-body">
                        <div class="col-sm-12">
                            <a href="<?php echo e(route('reporting.index')); ?>" class="mr-3 mt-1">
                                <button class="btn btn-sm btn-secondary float-right mb-3"> Kembali</button>
                            </a>
                        </div>
                        <div class="table-responsive">
                            <table class="table" id="dataTable" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Guru</th>
                                        <th>NUPTK</th>
                                        <th>Status Ketenagaan</th>
                                        <th>Pendidikan Terakhir</th>
                                        <th>Status Sertifikasi</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($teacher->teacher_name); ?></td>
                                        <td><?php echo e($teacher->nuptk); ?></td>
                                        <td><?php echo e($teacher->employment_status); ?></td>
                                        <td><?php echo e($teacher->last_education); ?></td>
                                        <td><?php echo e($teacher->certification_status); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('reporting.school.teacher.show', [ $school, $teacher ])); ?>" class="btn btn-sm btn-info btn-rounded btn-sm"><i class="fas fa-eye"></i></a>
                                            <a href="<?php echo e(route('reporting.teacher.print', $teacher)); ?>" class="btn btn-sm btn-primary"><i class="fas fa-print"></i> Print</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\projects\monev-tekkom\resources\views/reporting/teacher.blade.php ENDPATH**/ ?>