<x-app-layout>
    <livewire:district.index/>
</x-app-layout>