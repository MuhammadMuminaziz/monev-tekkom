<div>
    <form wire:submit.prevent="update">
        <input wire:model="id" type="hidden">
        <div class="form-group">
            <input wire:model="name" type="text" name="name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="name"
                placeholder="masukan nama kota" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-sm px-4 btn-warning rounded-pill mr-1">Edit Data</button>
            <button wire:click="censelUpdate()" type="button" class="btn btn-sm px-4 btn-danger rounded-pill">Cencel</button>
        </div>
    </form>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/city/update.blade.php ENDPATH**/ ?>