<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card shadow p-3 text-dark">
                    <div class="card-header bg-primary mb-2 text-white">
                        <h2>Periode Active <?php echo e($periode->year); ?></button></h1>
                        <div class="row">
                            <div class="col-md-12 my-3">
                                <form action="<?php echo e(route('periode.update')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="input-group input-group">
                                        <select name="name" id="name" class="form-control"
                                            aria-describedby="button-addon2">
                                            <option value="" selected disabled>Pilih Tahun Periode </option>
                                            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($year->name); ?>"><?php echo e($year->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-outline-light" type="submit"
                                                id="button-addon2">Change Periode</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\projects\monev_tekkom\resources\views/periode/index.blade.php ENDPATH**/ ?>