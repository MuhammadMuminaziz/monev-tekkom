<div>
    
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert" style="z-index: 99; top: 80px; right: 10px;">
      <?php echo e(session('message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div>
  <?php endif; ?>
  
    <table class="table">
        <thead>
          <tr>
            <th scope="col"></th>
            <th scope="col">Nama Guru</th>
            <th scope="col">Desa/Kabupaten</th>
            <th scope="col">Kecamatan/Kota</th>
            <th scope="col">Aksi</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $teachersNotActived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($teacher->teacher_name); ?></td>
            <td><?php echo e($teacher->district->name); ?></td>
            <td><?php echo e($teacher->city->name); ?></td>
            <td>
                <button wire:click="verify(<?php echo e($teacher); ?>)" class="btn btn-sm btn-success">Verify</button>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="row">
        <div class="col">
            <ol class="mt-5" type="1">
                <?php $__currentLoopData = $teachersActived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="d-flex justify-content-between bg-secondary rounded-pill py-2 px-5 text-white"><?php echo e($teacher->teacher_name); ?> <span class="btn btn-sm btn-light rounded-pill px-4">Active</span></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ol>
        </div>
      </div>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/teacher/edit.blade.php ENDPATH**/ ?>