<div class="card p-5">
    <h1>Data anda Berhasil di verifikasi</h1>
    <a href="<?php echo e(route('schools.show', $school)); ?>" class="btn btn-sm btn-success">Lihat Data</a>
</div><?php /**PATH E:\projects\monev_tekkom\resources\views/components/school-data.blade.php ENDPATH**/ ?>