<div class="container-fluid">
  
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert" style="z-index: 99; top: 80px; right: 10px;">
      <?php echo e(session('message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div>
  <?php endif; ?>
  <div class="row">
      <div class="col">
          <h1 class="h3 mb-2 text-gray-800">Verifikator</h1>
          <div class="card shadow">
              <div class="card-header py-3">
                  <h6 class="m-0 font-weight-bold text-primary">Data Sekolah</h6>
              </div>
              <div class="card-body">
                  <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                          <thead>
                              <th width="5%">No</th>
                              <th>Nama Sekolah</th>
                              <th>NPSN</th>
                              <th>Jumlah Siswa</th>
                              <th>Desa / Kecamatan</th>
                              <th>Aksi</th>
                          </thead>
                          <tbody>
                              <?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <td><?php echo e($loop->iteration); ?></td>
                              <td><?php echo e($school->name); ?></td>
                              <td><?php echo e($school->npsn); ?></td>
                              <td><?php echo e($school->jumlah_siswa); ?></td>
                              <td><?php echo e($school->district->name); ?></td>
                              <td>
                                <button wire:click="verify(<?php echo e($school); ?>)" class="btn btn-sm btn-success">Verifikasi</button>
                                <button wire:click="reject(<?php echo e($school); ?>)" class="btn btn-sm btn-danger">Tolak</button>
                                <a href="<?php echo e(route('verifikator.show', $school)); ?>" class="btn btn-sm btn-primary">Lihat</a>
                              </td>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </tbody>
                      </table>
                  </div>
              </div>
          </div>
      </div>
  </div>
</div>
<?php /**PATH E:\projects\monev_tekkom\resources\views/livewire/school/edit.blade.php ENDPATH**/ ?>