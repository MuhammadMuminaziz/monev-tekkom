<x-app-layout>
    <h1>Teacher</h1>

    <livewire:teacher.edit/>
</x-app-layout>