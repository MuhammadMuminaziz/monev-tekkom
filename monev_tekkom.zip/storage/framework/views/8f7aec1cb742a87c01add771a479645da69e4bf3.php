<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card shadow">
                    <div class="card-header">
                        <h6 class="card-title">Data Guru</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <h5><strong>A. Data Umum</strong></h5>
                               
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Nama Guru / Tenaga
                                                Administrasi</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->teacher_name); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Status Ketenagaan</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->employment_status); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">NIP</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->nip); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">NUPTK</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->nuptk); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Tempat, Tanggal Lahir</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->place_of_birth . ', ' . $teacher->date_of_birth); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Agama</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->religion); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Jenis Kelamin</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->gender); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Pendidikan Terakhir</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->last_education); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">TMT PNS</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->tmt_pns_tahun . $teacher->tmt_pns_bulan); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Pangkat / Golongan</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->class); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">TMT Golongan</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->tmt_class_tahun . $teacher->tmt_class_bulan); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Asal Sekolah</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->School_Origin); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Desa / Kecamatan</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->district->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Kabupaten / Kota</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->city->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Propinsi</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->provinsi); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">No Telpon/HP</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->phone); ?></td>
                                        </tr>

                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-6">
                                <h5><strong>B. Data Kompetensi</strong></h5>
                             
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Mata pelajaran yang
                                                diampu</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->subjects_taught); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Program atau kegiatan yang
                                                dilaksanakan</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->program); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Status Sertifikasi</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->certification_status); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Tahun Sertifikasi</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->certification_year); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Alasan Belum Sertifikasi</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->reason_not_certified); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Kompetensi yang dimiliki</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->competencies_taught); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Kegiatan Sosialisasi UNBK</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->unbk_socialization_activities); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Keterlibatan dalam UNBK</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->unbk_socialization_activities); ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row" class="col-sm-4">Riwayat Keterlibatan dalam
                                                UNBK</th>
                                            <td width="5%">:</td>
                                            <td><?php echo e($teacher->involvement_unbk); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-12">
                                <h6><strong>Pelatihan yang pernah diikuti</strong></h6>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">No</th>
                                            <th scope="col">Nama Diklat/Workshop/Seminar</th>
                                            <th scope="col">Tingkatan/Jenis Diklat</th>
                                            <th scope="col">Jampel</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($index + 1); ?></th>
                                            <td><?php echo e($training->name); ?></td>
                                            <td><?php echo e($training->level); ?></td>
                                            <td><?php echo e($training->jampel); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-sm-12">
                                <table class="table table-borderless">
                                    <tbody>
                                        <tr>
                                            <th scope="row" class="col-sm-2">Kebutuhan diklat saat ini</th>
                                            <td width="5%">:</td>
                                            <td>
                                                <?php $__currentLoopData = $training_needs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $need): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span><?php echo e($need->name); ?>, </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="col-sm-12">
                                    <a href="<?php echo e(route('teachers.index')); ?>" class="btn btn-primary">Kembali</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH E:\projects\monev_tekkom\resources\views/teacher/show.blade.php ENDPATH**/ ?>